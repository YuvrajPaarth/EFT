// product data
var products = [
  { id: 1, name: "Wooden ABC Blocks", age: "1-3", price: 799, img: "blocks.svg",
    desc: "Chunky wooden blocks with letters and bright colours. Easy for small hands to grip and stack.",
    skills: ["Letter recognition", "Hand-eye coordination", "Stacking and balance"] },
  { id: 2, name: "Rainbow Stacking Rings", age: "1-3", price: 549, img: "rings.svg",
    desc: "Five soft-edged rings that stack on a wooden pole, largest at the bottom.",
    skills: ["Sizes and order", "Colours", "Fine motor skills"] },
  { id: 3, name: "Picture Puzzle Set", age: "4-6", price: 649, img: "puzzle.svg",
    desc: "Thick-piece jigsaw puzzles with animal pictures. Comes with a storage tray.",
    skills: ["Problem solving", "Shape matching", "Patience"] },
  { id: 4, name: "Bead Counting Frame", age: "4-6", price: 899, img: "abacus.svg",
    desc: "A classic abacus with ten sliding beads on each row, good for first sums.",
    skills: ["Counting to 100", "Addition basics", "Number patterns"] },
  { id: 5, name: "Mini Science Lab Kit", age: "7-10", price: 1499, img: "science.svg",
    desc: "Test tubes, a flask and safe materials for 20 simple experiments you can do at home.",
    skills: ["Observation", "Following steps", "Basic chemistry ideas"] },
  { id: 6, name: "Build-a-Robot Kit", age: "7-10", price: 1999, img: "robot.svg",
    desc: "Snap-together robot with 120 pieces and a picture manual. No tools needed.",
    skills: ["Logical thinking", "Simple engineering", "Reading instructions"] }
];

var cart = [];
try { cart = JSON.parse(localStorage.getItem("learnsmart-cart")) || []; } catch (e) { cart = []; }

var listEl = document.getElementById("product-list");
var detailsEl = document.getElementById("details");
var cartItemsEl = document.getElementById("cart-items");

function findProduct(id) {
  return products.filter(function (p) { return p.id === id; })[0];
}

function showProducts(age) {
  var html = "";
  products.forEach(function (p) {
    if (age !== "all" && p.age !== age) return;
    html += '<div class="card">' +
      '<span class="age">Ages ' + p.age + '</span>' +
      '<img src="images/' + p.img + '" alt="' + p.name + '">' +
      '<div class="card-body"><h3>' + p.name + '</h3>' +
      '<p class="price">Rs. ' + p.price + '</p>' +
      '<div class="card-btns">' +
      '<button class="btn small alt" data-view="' + p.id + '">Details</button>' +
      '<button class="btn small" data-add="' + p.id + '">Add to cart</button>' +
      '</div></div></div>';
  });
  listEl.innerHTML = html;
}

function showDetails(id) {
  var p = findProduct(id);
  var skills = p.skills.map(function (s) { return "<li>" + s + "</li>"; }).join("");
  detailsEl.innerHTML =
    '<h2>Product details</h2><div class="detail-box">' +
    '<img src="images/' + p.img + '" alt="' + p.name + '">' +
    '<div><h3>' + p.name + '</h3>' +
    '<p><strong>Learning age group:</strong> ' + p.age + ' years</p>' +
    '<p class="price">Rs. ' + p.price + '</p>' +
    '<p>' + p.desc + '</p>' +
    '<p><strong>Your child will practise:</strong></p><ul>' + skills + '</ul>' +
    '<button class="btn" data-add="' + p.id + '">Add to cart</button> ' +
    '<button class="btn alt" id="close-details">Close</button></div></div>';
  detailsEl.hidden = false;
  detailsEl.scrollIntoView();
}

function saveCart() {
  try { localStorage.setItem("learnsmart-cart", JSON.stringify(cart)); } catch (e) {}
}

function addToCart(id) {
  var item = cart.filter(function (c) { return c.id === id; })[0];
  if (item) item.qty++;
  else cart.push({ id: id, qty: 1 });
  drawCart();
}

function changeQty(id, change) {
  cart.forEach(function (c) { if (c.id === id) c.qty += change; });
  cart = cart.filter(function (c) { return c.qty > 0; });
  drawCart();
}

function removeItem(id) {
  cart = cart.filter(function (c) { return c.id !== id; });
  drawCart();
}

function drawCart() {
  var html = "", total = 0, count = 0;
  cart.forEach(function (c) {
    var p = findProduct(c.id);
    total += p.price * c.qty;
    count += c.qty;
    html += '<div class="cart-row">' +
      '<img src="images/' + p.img + '" alt="">' +
      '<div class="info"><strong>' + p.name + '</strong><br>Rs. ' + p.price + ' each</div>' +
      '<div class="qty"><button data-minus="' + p.id + '">-</button><span>' + c.qty + '</span><button data-plus="' + p.id + '">+</button></div>' +
      '<strong>Rs. ' + (p.price * c.qty) + '</strong>' +
      '<button class="remove" data-remove="' + p.id + '">Remove</button></div>';
  });
  if (cart.length === 0) html = '<p class="empty">Your cart is empty. Pick a toy above!</p>';
  cartItemsEl.innerHTML = html;
  document.getElementById("cart-total").textContent = "Rs. " + total;
  document.getElementById("cart-count").textContent = count;
  saveCart();
}

// clicks
document.addEventListener("click", function (e) {
  var t = e.target;
  if (t.dataset.add) addToCart(Number(t.dataset.add));
  if (t.dataset.view) showDetails(Number(t.dataset.view));
  if (t.dataset.plus) changeQty(Number(t.dataset.plus), 1);
  if (t.dataset.minus) changeQty(Number(t.dataset.minus), -1);
  if (t.dataset.remove) removeItem(Number(t.dataset.remove));
  if (t.id === "close-details") detailsEl.hidden = true;
  if (t.classList.contains("cat")) {
    document.querySelectorAll(".cat").forEach(function (b) { b.classList.remove("active"); });
    t.classList.add("active");
    showProducts(t.dataset.age);
    document.getElementById("products").scrollIntoView();
  }
});

document.getElementById("clear-cart").addEventListener("click", function () {
  cart = [];
  drawCart();
});

showProducts("all");
drawCart();
